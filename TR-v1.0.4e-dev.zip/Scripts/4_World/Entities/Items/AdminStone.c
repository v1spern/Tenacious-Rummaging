class AdminStone extends ItemBase
{
    // HI MOM
}