class AdminPebble extends ItemBase
{
}
